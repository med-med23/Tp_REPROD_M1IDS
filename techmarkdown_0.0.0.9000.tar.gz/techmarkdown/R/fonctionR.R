
#' @param n entier
#' @return logical
#'
#'
#'
#' @export
nombre_pair_med <-function(n)
{
  if (n%%2==0)
    return(TRUE)
  else
    return(FALSE)
}
